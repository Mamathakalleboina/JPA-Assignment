insert into Employee(id, name, age, designation, salary) values(10001,'Vaibhav',22,'Manager','50000');
insert into Employee(id, name, age, designation, salary) values(10002,'Bhushan',21,'Developer','40000');
insert into Employee(id, name, age, designation, salary) values(10003,'Ram',24,'Owner','60000');